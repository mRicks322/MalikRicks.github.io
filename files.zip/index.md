---
layout: home
title: "Home"
---
# Malik Ricks, CISSP

Professional site hosted with GitHub Pages.

## About
Cybersecurity expert and IT professional.

## Projects
- Project A — brief description
- Project B — brief description

## Contact
Email: [you@example.com](mailto:you@example.com)